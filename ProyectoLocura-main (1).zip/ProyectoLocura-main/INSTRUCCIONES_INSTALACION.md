# IN## Archivos incluidos:

### 📋 requirements.txt
Contiene todas las dependencias necesarias para ejecutar la aplicación:
- `flet` - Framework para la interfaz gráfica
- `pandas` - Para manejo de datos y exportación
- `importlib-metadata` - Compatibilidad con versiones de Python

### 🚀 GimnasioApp.bat ⭐ **ARCHIVO PRINCIPAL**
Script único que hace todo automáticamente:
1. ✅ Verifica que Python esté instalado
2. 🔍 Verifica si las dependencias están instaladas
3. 📦 Si faltan dependencias, pregunta si quieres instalarlas
4. ⚡ Instala automáticamente lo que falta
5. ▶️ Ejecuta la aplicaciónR UNIFICADO - GIMNASIO APP

Este proyecto incluye un archivo único que maneja tanto la instalación como la ejecución de la aplicación de gestión de gimnasio.

## Archivos incluidos:

### 📋 requirements.txt
Contiene todas las dependencias necesarias para ejecutar la aplicación:
- `flet` - Framework para la interfaz gráfica
- `pandas` - Para manejo de datos y exportación
- `importlib-metadata` - Compatibilidad con versiones de Python

### � GimnasioApp.bat ⭐ **ARCHIVO PRINCIPAL**
Script único que hace todo automáticamente:
1. ✅ Verifica que Python esté instalado
2. 🔍 Verifica si las dependencias están instaladas
3. 📦 Si faltan dependencias, pregunta si quieres instalarlas
4. ⚡ Instala automáticamente lo que falta
5. ▶️ Ejecuta la aplicación

### 🗂️ instalar_dependencias.bat y ejecutar_app.bat
Scripts separados (opcionales, pero ya no necesarios con GimnasioApp.bat)

## Instrucciones de uso:

### ⚡ SÚPER FÁCIL - Un solo click:
**Simplemente haz doble clic en `GimnasioApp.bat`**

Eso es todo! El archivo hará todo automáticamente:
- Si es la primera vez, instalará las dependencias
- Si ya están instaladas, directamente ejecutará la app

### Para una nueva PC:
1. Copia toda la carpeta del proyecto
2. Haz doble clic en `GimnasioApp.bat` 
3. Cuando pregunte si quieres instalar dependencias, presiona **S**
4. ¡Listo! Se instala todo y ejecuta la app

### Para uso diario:
- Simplemente hacer doble clic en `GimnasioApp.bat`

## Requisitos previos:
- Python 3.8 o superior instalado en el sistema
- Conexión a internet para descargar las dependencias (solo la primera vez)

## Solución de problemas:
- Si Python no está instalado, descárgalo desde: https://python.org
- Asegúrate de marcar "Add Python to PATH" durante la instalación
- Si tienes problemas con permisos, ejecuta como administrador

## Notas adicionales:
- Los archivos .bat solo funcionan en Windows
- Las dependencias se instalan una sola vez por cada entorno de Python
- La aplicación creará una base de datos SQLite automáticamente en la primera ejecución
