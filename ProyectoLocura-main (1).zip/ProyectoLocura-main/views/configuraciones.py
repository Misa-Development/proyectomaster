import flet as ft
import json
from tematica import setear_colores
from views.Menu import vista_menu
from views.administrativoSector import sector_admin

CONFIG_FILE = "config.json"

def cargar_configuracion():
    try:
        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)
    except FileNotFoundError:
        config = {
            "color_fondo": "#FFFFFF",
            "color_tematica": "#FF5733",
            "color_letras": "#000000",
            "tema": "Light",
            "nombre_gimnasio": "Mi Gimnasio",
            "idioma": "Español",
            "admin_email": "admin@ejemplo.com"
        }
        guardar_configuracion(config)
        return config

    claves_necesarias = {
        "color_fondo": "#FFFFFF",
        "color_tematica": "#FF5733",
        "color_letras": "#000000",
        "tema": "Light",
        "nombre_gimnasio": "Mi Gimnasio",
        "idioma": "Español",
        "admin_email": "admin@ejemplo.com"
    }
    for clave, valor_defecto in claves_necesarias.items():
        if clave not in config:
            config[clave] = valor_defecto
    return config

def guardar_configuracion(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)
    
    # Invalidar cache en otros módulos para reflejar cambios en tiempo real
    try:
        from views.verdetalle import invalidar_cache_configuracion as invalidar_verdetalle
        invalidar_verdetalle()
        print("[DEBUG] Cache de verdetalle invalidado tras guardar configuración")
    except ImportError:
        print("[DEBUG] No se pudo invalidar cache de verdetalle")
    
    try:
        from views.vistaedicion import invalidar_cache_configuracion as invalidar_vistaedicion
        invalidar_vistaedicion()
        print("[DEBUG] Cache de vistaedicion invalidado tras guardar configuración")
    except ImportError:
        print("[DEBUG] No se pudo invalidar cache de vistaedicion")

def aplicar_tema(page, configuracion):
    tema = configuracion["tema"]
    if tema == "Light":
        configuracion["color_fondo"] = "#FBF7E3"
        configuracion["color_tematica"] = "#E97127"
        configuracion["color_letras"] = "#000000"
    elif tema == "Dark":
        configuracion["color_fondo"] = "#0d1117"
        configuracion["color_tematica"] = "#F48946"
        configuracion["color_letras"] = "#FFFFFF"

    setear_colores(page, configuracion["color_fondo"], configuracion["color_tematica"], configuracion["color_letras"])
    guardar_configuracion(configuracion)
    page.bgcolor = configuracion["color_fondo"]
    page.update()

def vista_configuracion_tema(page, configuracion, reconstruir_vista):
    def cambiar_tema(e):
        configuracion["tema"] = selector_tema.value
        aplicar_tema(page, configuracion)
        reconstruir_vista()

    def cambiar_color_tematica(e):
        color_input = ft.TextField(
            label="Color HEX",
            hint_text="#E97127",
            value=configuracion["color_tematica"],
            border_color=configuracion["color_tematica"],
            text_style=ft.TextStyle(color=configuracion["color_letras"]),
            bgcolor=configuracion["color_fondo"]
        )
        error_text = ft.Text("", color="red")
        preview_box = ft.Container(width=40, height=40, bgcolor=color_input.value, border=ft.border.all(1, color="#888"), border_radius=5)

        def actualizar_preview(ev):
            color = color_input.value.strip()
            if color.startswith("#") and len(color) in (7, 4):
                try:
                    int(color[1:], 16)
                    preview_box.bgcolor = color
                except ValueError:
                    preview_box.bgcolor = "#fff"
            else:
                preview_box.bgcolor = "#fff"
            page.update()

        color_input.on_change = actualizar_preview

        def guardar_color(ev):
            color = color_input.value.strip()
            if color.startswith("#") and len(color) in (7, 4):
                try:
                    int(color[1:], 16)
                    configuracion["color_tematica"] = color
                    guardar_configuracion(configuracion)
                    aplicar_tema(page, configuracion)
                    page.dialog.open = False
                    page.update()
                    reconstruir_vista()
                    return
                except ValueError:
                    pass
            error_text.value = "Color HEX inválido. Ejemplo: #E97127"
            page.update()

        def cerrar_dialogo(ev=None):
            page.dialog.open = False
            page.update()

        page.dialog = ft.AlertDialog(
            title=ft.Text("Selecciona un color temático (HEX)"),
            content=ft.Column([
                ft.Row([color_input, preview_box], spacing=10),
                error_text
            ], tight=True),
            actions=[
                ft.TextButton("Guardar", on_click=guardar_color),
                ft.TextButton("Cancelar", on_click=cerrar_dialogo)
            ],
            open=True
        )
        page.update()
        def cerrar_dialogo():
            page.dialog.open = False
            page.update()

    selector_tema = ft.Dropdown(
        label="Tema",
        options=[
            ft.dropdown.Option(key="Light", text="Tema Claro", style=ft.TextStyle(color=configuracion["color_letras"])),
            ft.dropdown.Option(key="Dark", text="Tema Oscuro", style=ft.TextStyle(color=configuracion["color_letras"]))
        ],
        value=configuracion["tema"],
        label_style=ft.TextStyle(color=configuracion["color_letras"]),
        text_style=ft.TextStyle(color=configuracion["color_letras"]),
        border_color=configuracion["color_letras"],
        bgcolor=configuracion["color_fondo"]
    )

    boton_guardar_tema = ft.ElevatedButton(
        text="Guardar Tema",
        icon=ft.Icons.COLOR_LENS,
        style=ft.ButtonStyle(bgcolor=configuracion["color_tematica"], color="black"),
        on_click=cambiar_tema
    )

    boton_color_tematica = ft.ElevatedButton(
        text="Tematica",
        icon=ft.Icons.PALETTE,
        style=ft.ButtonStyle(bgcolor=configuracion["color_tematica"], color="white"),
        on_click=cambiar_color_tematica
    )

    return ft.Container(
        content=ft.Column([
            ft.Text("Tema", style="headlineMedium", color=configuracion["color_letras"]),
            ft.Row([
                selector_tema,
                boton_color_tematica
            ], spacing=10),
            boton_guardar_tema
        ]),
        padding=10,
        border=ft.border.all(1, color=configuracion["color_tematica"]),
        border_radius=5,
        bgcolor=configuracion["color_fondo"]
    )

def vista_configuraciones(page):
    page.title = "Configuraciones"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    configuracion = cargar_configuracion()
    aplicar_tema(page, configuracion)

    # Estado para el sector admin (deben estar aquí, no dentro de reconstruir_vista)
    admin_accedido = [False]
    email_valor = [configuracion.get("admin_email", "admin@ejemplo.com")]
    email_editando = [False]
    cambiando_password = [False]
    campo_actual_valor = [""]
    campo_nueva_valor = [""]
    campo_confirmar_valor = [""]

    def reconstruir_vista():
        titulo = ft.Text(
            "Configuraciones",
            style="displaySmall",
            color=configuracion["color_letras"],
            weight=ft.FontWeight.BOLD,
            text_align=ft.TextAlign.CENTER
        )
        menu = vista_menu(page)

        campo_nombre_gimnasio = ft.TextField(
            label="Nombre del Gimnasio",
            hint_text="Escribe aquí el nombre...",
            value=configuracion["nombre_gimnasio"],
            hint_style=ft.TextStyle(color=configuracion["color_tematica"]),
            label_style=ft.TextStyle(color=configuracion["color_letras"]),
            text_style=ft.TextStyle(color=configuracion["color_letras"]),
            border_color=configuracion["color_letras"],
            bgcolor=configuracion["color_fondo"]
        )

        selector_idioma = ft.Dropdown(
            label="Idioma",
            options=[
                ft.dropdown.Option(key="Español", text="Español", style=ft.TextStyle(color=configuracion["color_letras"])) ,
                ft.dropdown.Option(key="Inglés", text="Inglés", style=ft.TextStyle(color=configuracion["color_letras"]))
            ],
            value=configuracion["idioma"],
            label_style=ft.TextStyle(color=configuracion["color_letras"]),
            text_style=ft.TextStyle(color=configuracion["color_letras"]),
            border_color=configuracion["color_letras"],
            bgcolor=configuracion["color_fondo"]
        )

        def cambiar_nombre_gimnasio(e):
            configuracion["nombre_gimnasio"] = campo_nombre_gimnasio.value
            guardar_configuracion(configuracion)
            page.snack_bar = ft.SnackBar(
                content=ft.Text(
                    f"¡Nombre del gimnasio actualizado a '{configuracion['nombre_gimnasio']}'!",
                    color=configuracion["color_letras"]
                )
            )
            page.snack_bar.open = True

        boton_guardar_nombre = ft.ElevatedButton(
            text="Guardar Nombre",
            icon=ft.Icons.SAVE,
            style=ft.ButtonStyle(bgcolor=configuracion["color_tematica"], color="black"),
            on_click=cambiar_nombre_gimnasio
        )

        contenedor_gimnasio = ft.Container(
            content=ft.Column([
                ft.Text("Configuración del Gimnasio", style="headlineMedium", color=configuracion["color_letras"]),
                campo_nombre_gimnasio,
                boton_guardar_nombre
            ]),
            padding=10,
            border=ft.border.all(1, color=configuracion["color_tematica"]),  # Color tematica
            border_radius=5,
            bgcolor=configuracion["color_fondo"]
        )

        contenedor_apariencia = vista_configuracion_tema(page, configuracion, refrescar_vista)

        layout = ft.Column(
            [menu, titulo, contenedor_apariencia, contenedor_gimnasio],
            spacing=20,
            expand=True,
            scroll="auto"
        )
        admin_sector = sector_admin(
            page, configuracion, admin_accedido, email_valor, email_editando, cambiando_password,
            campo_actual_valor, campo_nueva_valor, campo_confirmar_valor,
            refrescar_vista, guardar_configuracion
        )
        layout.controls.append(admin_sector)
        return layout

    def refrescar_vista():
        # Si hay un diálogo abierto, lo guardamos y lo reasignamos tras refrescar la vista
        dialog_abierto = None
        if hasattr(page, 'dialog') and page.dialog and getattr(page.dialog, 'open', False):
            dialog_abierto = page.dialog
        page.controls.clear()
        page.controls.append(reconstruir_vista())
        if dialog_abierto:
            page.dialog = dialog_abierto
        page.update()

    refrescar_vista()
    # No retornamos nada, ya que la vista se asigna directamente a page.controls