
import flet as ft
import sqlite3
import os
import pandas as pd

def mostrar_popup_listas_bbdd(page, db_path):
    if not os.path.exists(db_path):
        tablas = []
        error = "No se encontró la base de datos"
    else:
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tablas = [row[0] for row in cursor.fetchall()]
            conn.close()
            error = None
        except Exception as e:
            tablas = []
            error = f"Error: {e}"

    file_picker = ft.FilePicker()
    page.overlay.append(file_picker)

    def exportar_tabla(tabla):
        def on_result(e):
            if not e.path:
                page.snack_bar = ft.SnackBar(content=ft.Text("Exportación cancelada.", color="orange"))
                page.snack_bar.open = True
                return
            # Asegura que el archivo tenga extensión .xlsx
            save_path = e.path
            if not save_path.lower().endswith('.xlsx'):
                save_path += '.xlsx'
            try:
                conn = sqlite3.connect(db_path)
                df = pd.read_sql_query(f"SELECT * FROM {tabla}", conn)
                conn.close()
                
                # Verificar que hay datos para exportar
                if df.empty:
                    page.snack_bar = ft.SnackBar(content=ft.Text(f"La tabla '{tabla}' está vacía.", color="orange"))
                    page.snack_bar.open = True
                    return
                
                # Exportar a Excel con openpyxl
                df.to_excel(save_path, index=False, engine='openpyxl')
                
                # Verificar que el archivo se creó correctamente
                if os.path.exists(save_path) and os.path.getsize(save_path) > 0:
                    page.snack_bar = ft.SnackBar(content=ft.Text(f"✅ Tabla '{tabla}' exportada exitosamente.\n📁 {save_path}", color="green"))
                else:
                    page.snack_bar = ft.SnackBar(content=ft.Text(f"❌ Error: El archivo se creó vacío.", color="red"))
                
                page.snack_bar.open = True
                
            except ImportError as ie:
                page.snack_bar = ft.SnackBar(content=ft.Text(f"❌ Falta instalar openpyxl. Ejecuta: pip install openpyxl", color="red"))
                page.snack_bar.open = True
            except Exception as ex:
                page.snack_bar = ft.SnackBar(content=ft.Text(f"❌ Error al exportar: {ex}", color="red"))
                page.snack_bar.open = True
        file_picker.on_result = on_result
        file_picker.save_file(
            dialog_title=f"Exportar tabla '{tabla}' como Excel",
            file_type="custom",
            allowed_extensions=["xlsx"]
        )

    contenido = [ft.Text("Listas en la base de datos:", weight="bold", size=14, color="blue")]
    if error:
        contenido.append(ft.Text(error, color="red"))
    else:
        for tabla in tablas:
            contenido.append(
                ft.ElevatedButton(
                    text=tabla,
                    icon=ft.Icons.TABLE_CHART,
                    on_click=lambda e, t=tabla: exportar_tabla(t),
                    style=ft.ButtonStyle(bgcolor="#E3F2FD", color="#1565C0")
                )
            )

    def cerrar_popup(ev=None):
        page.dialog.open = False
        page.update()

    dialog = ft.AlertDialog(
        title=ft.Text("Tablas de la Base de Datos", color="blue", text_align="center", size=15),
        content=ft.Container(
            content=ft.Column(contenido, spacing=6, scroll="auto"),
            width=260,
            height=220,
            padding=10,
            alignment=ft.alignment.center
        ),
        actions=[ft.TextButton("Cerrar", on_click=cerrar_popup)],
        actions_alignment="end",
        open=True
    )
    page.dialog = dialog
    if hasattr(page, 'overlay') and page.overlay is not None:
        page.overlay.append(dialog)
    page.update()
