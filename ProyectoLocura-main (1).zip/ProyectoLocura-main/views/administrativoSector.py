import flet as ft
from views.exportacion import mostrar_popup_listas_bbdd
from views.reportexlsx import mostrar_selector_tablas

def sector_admin(page, configuracion, admin_accedido, email_valor, email_editando, cambiando_password,
                campo_actual_valor, campo_nueva_valor, campo_confirmar_valor,
                reconstruir_vista, guardar_configuracion):
    # Cargar la contraseña del admin desde la configuración o variable
    if "admin_password" not in configuracion:
        configuracion["admin_password"] = "MALDONADO"
    admin_password = configuracion["admin_password"]
    # Campos para el cambio de contraseña
    # Bandera para mostrar errores solo al intentar guardar
    if not hasattr(sector_admin, "mostrar_errores"):
        sector_admin.mostrar_errores = [False]
    mostrar_errores = sector_admin.mostrar_errores

    import re
    def validar_password(pw):
        if not pw:
            return ("", configuracion["color_letras"], None)
        if len(pw) < 8:
            return ("Debe tener al menos 8 caracteres", "#e57373", "Debe tener al menos 8 caracteres")
        if not re.search(r"[A-Za-z]", pw):
            return ("Debe contener al menos una letra", "#e57373", "Debe contener al menos una letra")
        if not re.search(r"[0-9]", pw):
            return ("Debe contener al menos un número", "#e57373", "Debe contener al menos un número")
        return ("Contraseña segura", "#43a047", None)

    def validar_actual(pw):
        if not pw:
            # Si está vacío, no mostrar error
            return ("", configuracion["color_letras"], None)
        if pw == admin_password:
            return ("Contraseña actual correcta", "#43a047", None)
        else:
            # Mostrar error solo si hay algo escrito y es incorrecta
            return ("Contraseña actual incorrecta", "#e57373", "Contraseña actual incorrecta")

    def on_change_actual(e):
        campo_actual_valor[0] = e.control.value
        page.update()

    def validar_confirmar(nueva, confirmar):
        if not confirmar:
            return ("", configuracion["color_letras"], None)
        if nueva != confirmar:
            return ("La confirmación no coincide", "#e57373", "La confirmación no coincide")
        return ("Coinciden", "#43a047", None)
    def on_change_nueva(e):
        campo_nueva_valor[0] = e.control.value
        page.update()

    def on_change_actual(e):
        campo_actual_valor[0] = e.control.value
        page.update()

    def on_change_confirmar(e):
        campo_confirmar_valor[0] = e.control.value
        page.update()

    # Validaciones visuales
    mensaje_actual, color_actual, error_actual = validar_actual(campo_actual_valor[0])
    mensaje_nueva, color_nueva, error_nueva = validar_password(campo_nueva_valor[0])
    mensaje_confirmar, color_confirmar, error_confirmar = validar_confirmar(campo_nueva_valor[0], campo_confirmar_valor[0])

    # Mensaje de ayuda visual para contraseña actual
    # Lógica de color y error igual que add_client.py
    def color_label_actual():
        return "red" if error_actual else configuracion["color_letras"]
    def color_borde_actual_fn():
        return "#e57373" if error_actual else configuracion["color_tematica"]
    ayuda_actual = ft.Text(
        mensaje_actual,
        color="#e57373" if error_actual else configuracion["color_letras"],
        size=12
    )
    campo_actual = ft.Column([
        ft.TextField(
            label="Contraseña actual",
            password=True,
            can_reveal_password=True,
            border_color=color_borde_actual_fn(),
            bgcolor=configuracion["color_fondo"],
            text_style=ft.TextStyle(color=configuracion["color_letras"]),
            value=campo_actual_valor[0],
            on_change=on_change_actual,
            label_style=ft.TextStyle(color=color_label_actual()),
            error_text=mensaje_actual if error_actual else None,
            max_length=20
        ),
        ayuda_actual
    ])
    ayuda_nueva = ft.Text(
        mensaje_nueva if mensaje_nueva else "",
        color="#e57373" if error_nueva else color_nueva,
        size=12
    )
    campo_nueva = ft.Column([
        ft.TextField(
            label="Nueva contraseña",
            password=True,
            can_reveal_password=True,
            border_color="#e57373" if error_nueva else configuracion["color_tematica"],
            bgcolor=configuracion["color_fondo"],
            text_style=ft.TextStyle(color=configuracion["color_letras"]),
            value=campo_nueva_valor[0],
            on_change=on_change_nueva,
            label_style=ft.TextStyle(color="#e57373" if error_nueva else configuracion["color_letras"]),
            error_text=mensaje_nueva if error_nueva else None
        ),
        ayuda_nueva
    ])
    ayuda_confirmar = ft.Text(
        mensaje_confirmar if mensaje_confirmar else "",
        color="#e57373" if error_confirmar else color_confirmar,
        size=12
    )
    campo_confirmar = ft.Column([
        ft.TextField(
            label="Confirmar nueva contraseña",
            password=True,
            can_reveal_password=True,
            border_color="#e57373" if error_confirmar else configuracion["color_tematica"],
            bgcolor=configuracion["color_fondo"],
            text_style=ft.TextStyle(color=configuracion["color_letras"]),
            value=campo_confirmar_valor[0],
            on_change=on_change_confirmar,
            label_style=ft.TextStyle(color="#e57373" if error_confirmar else color_confirmar),
            error_text=mensaje_confirmar if error_confirmar else None
        ),
        ayuda_confirmar
    ])

    def mostrar_cambiar_password(e):
        print("[DEBUG] mostrar_cambiar_password: cambiando_password antes:", cambiando_password[0])
        cambiando_password[0] = True
        print("[DEBUG] mostrar_cambiar_password: cambiando_password después:", cambiando_password[0])
        reconstruir_vista()

    def cancelar_cambiar_password(e):
        print("[DEBUG] cancelar_cambiar_password: cambiando_password antes:", cambiando_password[0])
        cambiando_password[0] = False
        campo_actual_valor[0] = ""
        campo_nueva_valor[0] = ""
        campo_confirmar_valor[0] = ""
        print("[DEBUG] cancelar_cambiar_password: cambiando_password después:", cambiando_password[0])
        # Cerrar cualquier diálogo abierto
        if hasattr(page, 'dialog') and page.dialog:
            page.dialog.open = False
            page.update()
        reconstruir_vista()

    def guardar_nueva_password(e):
        # Validaciones
        print("[DEBUG] guardar_nueva_password: actual=", campo_actual_valor[0], "nueva=", campo_nueva_valor[0], "confirmar=", campo_confirmar_valor[0])
        print("[DEBUG] guardar_nueva_password: admin_password actual:", admin_password)
        mostrar_errores[0] = True
        page.update()
        import re
        errores = []
        if not campo_actual_valor[0]:
            errores.append("Debes ingresar la contraseña actual.")
        elif campo_actual_valor[0] != admin_password:
            errores.append("La contraseña actual es incorrecta.")
        if not campo_nueva_valor[0]:
            errores.append("Debes ingresar la nueva contraseña.")
        elif len(campo_nueva_valor[0]) < 8 or not re.search(r"[A-Za-z]", campo_nueva_valor[0]) or not re.search(r"[0-9]", campo_nueva_valor[0]):
            errores.append("La nueva contraseña debe tener al menos 8 caracteres, una letra y un número.")
        if not campo_confirmar_valor[0]:
            errores.append("Debes confirmar la nueva contraseña.")
        elif campo_nueva_valor[0] != campo_confirmar_valor[0]:
            errores.append("La confirmación de la contraseña no coincide.")
        print("[DEBUG] errores:", errores)
        if errores:
            def cerrar_dialogo(e):
                page.dialog.open = False
                page.update()
                # Refresca la vista solo al cerrar el pop-up
                reconstruir_vista()
            # Limit number of error lines and reduce font size for compactness
            max_lines = 3
            errores_mostrar = errores[:max_lines]
            hay_mas = len(errores) > max_lines
            contenido_column = [
                ft.Text("Por favor, corrige los siguientes campos:", color="red", text_align="center", size=13),
                *[ft.Text(f"- {err}", color="red", text_align="center", size=12) for err in errores_mostrar]
            ]
            if hay_mas:
                contenido_column.append(ft.Text("...", color="red", text_align="center", size=12))
            dialog = ft.AlertDialog(
                title=ft.Text("Datos Ingresados Incorrectamente", color="red", text_align="center", size=15),
                content=ft.Container(
                    content=ft.Column(
                        contenido_column,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=2,
                        scroll="auto"
                    ),
                    width=210,
                    height=120,  # Limit height for a compact pop-up
                    padding=6,
                    alignment=ft.alignment.center
                ),
                actions=[ft.TextButton("Cerrar", on_click=cerrar_dialogo)],
                actions_alignment="end",
                open=True
            )
            print("[DEBUG] ALERTDIALOG ABIERTO")
            page.dialog = dialog
            if hasattr(page, 'overlay') and page.overlay is not None:
                page.overlay.append(dialog)
            page.update()
            return
        # Guardar nueva contraseña SOLO si no hay errores
        print("[DEBUG] guardar_nueva_password: cambiando contraseña...")
        configuracion["admin_password"] = campo_nueva_valor[0]
        guardar_configuracion(configuracion)
        print("[DEBUG] guardar_nueva_password: nueva contraseña guardada:", configuracion["admin_password"])
        cambiando_password[0] = False
        campo_actual_valor[0] = ""
        campo_nueva_valor[0] = ""
        campo_confirmar_valor[0] = ""
        mostrar_errores[0] = False
        def cerrar_exito(ev=None):
            page.dialog.open = False
            page.update()
            reconstruir_vista()
        dialog_exito = ft.AlertDialog(
            title=ft.Text("¡Éxito!", color="green", text_align="center", size=15),
            content=ft.Container(
                content=ft.Text("Contraseña guardada exitosamente", color="green", text_align="center", size=13),
                width=210,
                height=120,  # Match error pop-up size
                padding=10,
                alignment=ft.alignment.center
            ),
            actions=[ft.TextButton("Cerrar", on_click=cerrar_exito)],
            actions_alignment="end",
            open=True
        )
        page.dialog = dialog_exito
        if hasattr(page, 'overlay') and page.overlay is not None:
            page.overlay.append(dialog_exito)
        page.update()
    def acceder_admin(e):
        if campo_password.value == admin_password:
            admin_accedido[0] = True
            page.snack_bar = ft.SnackBar(content=ft.Text("¡Acceso concedido!", color="green"))
            page.snack_bar.open = True
            reconstruir_vista()
        else:
            page.snack_bar = ft.SnackBar(content=ft.Text("Contraseña incorrecta", color="red"))
            page.snack_bar.open = True

    def editar_email(e):
        email_editando[0] = True
        reconstruir_vista()

    def guardar_email(e):
        email_editando[0] = False
        email_valor[0] = campo_email.value
        configuracion["admin_email"] = email_valor[0]
        guardar_configuracion(configuracion)
        reconstruir_vista()

    def enviar_reporte_ahora(e):
        # Obtener el email actual del administrador
        email_actual = email_valor[0] if email_valor[0] else configuracion.get("admin_email", "admin@ejemplo.com")
        
        # Validar que hay un email configurado
        if not email_actual or email_actual == "admin@ejemplo.com":
            page.snack_bar = ft.SnackBar(content=ft.Text("Por favor configure un email válido antes de enviar reportes", color="red"))
            page.snack_bar.open = True
            page.update()
            return
        
        # Mostrar selector de tablas
        mostrar_selector_tablas(page, email_actual)

    def enviar_reporte_mes(e):
        page.snack_bar = ft.SnackBar(content=ft.Text("Reporte mensual programado para " + email_valor[0], color="green"))
        page.snack_bar.open = True

    def exportar_bbdd(e):
        db_path = "database/clientes_gimnasio.db"  # Ajusta la ruta si tu base está en otro lugar
        mostrar_popup_listas_bbdd(page, db_path)

    if not admin_accedido[0]:
        campo_password = ft.TextField(
            label="Contraseña Administrador",
            password=True,
            can_reveal_password=True,
            border_color=configuracion["color_letras"],
            bgcolor=configuracion["color_fondo"],
            text_style=ft.TextStyle(color=configuracion["color_letras"])
        )
        admin_sector = ft.Container(
            content=ft.Column([
                ft.Text("SECTOR ADMINISTRADOR", style="headlineMedium", color=configuracion["color_tematica"], weight=ft.FontWeight.BOLD),
                campo_password,
                ft.ElevatedButton("Acceder", icon=ft.Icons.LOCK_OPEN, on_click=acceder_admin, style=ft.ButtonStyle(bgcolor=configuracion["color_tematica"]))
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            padding=20, border=ft.border.all(2, configuracion["color_tematica"]), border_radius=10, margin=20
        )
    else:
        if cambiando_password[0]:
            color_titulo = "#e57373" if error_actual else configuracion["color_tematica"]
            print(f"[DEBUG] color_titulo: {color_titulo} (error_actual: {error_actual})")
            admin_sector = ft.Container(
                content=ft.Column([
                    ft.Text("CAMBIAR CONTRASEÑA", style="headlineMedium", color=color_titulo, weight=ft.FontWeight.BOLD),
                    campo_actual,
                    campo_nueva,
                    campo_confirmar,
                    ft.Row([
                        ft.ElevatedButton("Guardar", icon=ft.Icons.SAVE, on_click=guardar_nueva_password, style=ft.ButtonStyle(bgcolor=configuracion["color_tematica"])),
                        ft.ElevatedButton("Cancelar", icon=ft.Icons.CANCEL, on_click=cancelar_cambiar_password, style=ft.ButtonStyle(bgcolor="#888888"))
                    ])
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
                padding=20, border=ft.border.all(2, configuracion["color_tematica"]), border_radius=10, margin=20
            )
        else:
            campo_email = ft.TextField(
                label="Email de Reportes",
                value=email_valor[0],
                read_only=not email_editando[0],
                bgcolor="#e0e0e0" if not email_editando[0] else configuracion["color_fondo"],
                text_style=ft.TextStyle(color="#888888" if not email_editando[0] else configuracion["color_letras"]),
                border_color=configuracion["color_letras"]
            )
            admin_sector = ft.Container(
                content=ft.Column([
                    ft.Text("SECTOR ADMINISTRADOR", style="headlineMedium", color=configuracion["color_tematica"], weight=ft.FontWeight.BOLD),
                    campo_email,
                    ft.Row([
                        ft.ElevatedButton("Editar", icon=ft.Icons.EDIT, on_click=editar_email, disabled=email_editando[0], style=ft.ButtonStyle(bgcolor=configuracion["color_tematica"])),
                        ft.ElevatedButton("Guardar", icon=ft.Icons.SAVE, on_click=guardar_email, disabled=not email_editando[0], style=ft.ButtonStyle(bgcolor=configuracion["color_tematica"]))
                    ], alignment=ft.MainAxisAlignment.CENTER, spacing=10),
                    ft.Divider(color=configuracion["color_tematica"]),
                    # Fila profesional con los 4 botones principales
                    ft.Row([
                        ft.Container(
                            content=ft.ElevatedButton(
                                content=ft.Column([
                                    ft.Icon(ft.Icons.SEND, size=20, color="white"),
                                    ft.Text("Enviar\nReporte", size=11, color="white", text_align=ft.TextAlign.CENTER, weight=ft.FontWeight.BOLD)
                                ], spacing=4, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                                on_click=enviar_reporte_ahora,
                                style=ft.ButtonStyle(
                                    bgcolor=configuracion["color_tematica"],
                                    shape=ft.RoundedRectangleBorder(radius=12),
                                    padding=ft.padding.all(12)
                                ),
                                width=120,
                                height=70
                            ),
                            tooltip="Enviar reporte inmediatamente"
                        ),
                        ft.Container(
                            content=ft.ElevatedButton(
                                content=ft.Column([
                                    ft.Icon(ft.Icons.SCHEDULE, size=20, color="white"),
                                    ft.Text("Reporte\nMensual", size=11, color="white", text_align=ft.TextAlign.CENTER, weight=ft.FontWeight.BOLD)
                                ], spacing=4, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                                on_click=enviar_reporte_mes,
                                style=ft.ButtonStyle(
                                    bgcolor=configuracion["color_tematica"],
                                    shape=ft.RoundedRectangleBorder(radius=12),
                                    padding=ft.padding.all(12)
                                ),
                                width=120,
                                height=70
                            ),
                            tooltip="Programar reporte mensual"
                        ),
                        ft.Container(
                            content=ft.ElevatedButton(
                                content=ft.Column([
                                    ft.Icon(ft.Icons.DOWNLOAD, size=20, color="white"),
                                    ft.Text("Exportar\nBBDD", size=11, color="white", text_align=ft.TextAlign.CENTER, weight=ft.FontWeight.BOLD)
                                ], spacing=4, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                                on_click=exportar_bbdd,
                                style=ft.ButtonStyle(
                                    bgcolor=configuracion["color_tematica"],
                                    shape=ft.RoundedRectangleBorder(radius=12),
                                    padding=ft.padding.all(12)
                                ),
                                width=120,
                                height=70
                            ),
                            tooltip="Exportar base de datos"
                        ),
                        ft.Container(
                            content=ft.ElevatedButton(
                                content=ft.Column([
                                    ft.Icon(ft.Icons.PASSWORD, size=20, color="white"),
                                    ft.Text("Cambiar\nContraseña", size=11, color="white", text_align=ft.TextAlign.CENTER, weight=ft.FontWeight.BOLD)
                                ], spacing=4, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                                on_click=mostrar_cambiar_password,
                                style=ft.ButtonStyle(
                                    bgcolor="#FFA726",
                                    shape=ft.RoundedRectangleBorder(radius=12),
                                    padding=ft.padding.all(12)
                                ),
                                width=120,
                                height=70
                            ),
                            tooltip="Cambiar contraseña de administrador"
                        )
                    ], alignment=ft.MainAxisAlignment.CENTER, spacing=15, wrap=True)
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=15),
                padding=25, border=ft.border.all(2, configuracion["color_tematica"]), border_radius=12, margin=20
            )
    return admin_sector