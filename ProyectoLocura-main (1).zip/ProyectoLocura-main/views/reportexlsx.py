import flet as ft
import sqlite3
import pandas as pd
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
import tempfile
import json
from database.db import conectar_db

CONFIG_FILE = "config.json"

def cargar_configuracion():
    """Carga la configuración desde el archivo JSON"""
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {
            "color_fondo": "#FFFFFF",
            "color_tematica": "#E8E8E8", 
            "color_letras": "#000000",
            "admin_email": "admin@ejemplo.com"
        }

def obtener_tablas_bd():
    """Obtiene la lista de tablas de la base de datos"""
    try:
        conn = conectar_db()
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [tabla[0] for tabla in cursor.fetchall()]
        conn.close()
        return tablas
    except Exception as e:
        print(f"Error obteniendo tablas: {e}")
        return []

def exportar_tabla_a_excel(tabla_nombre, ruta_archivo):
    """Exporta una tabla específica a Excel"""
    try:
        conn = conectar_db()
        df = pd.read_sql_query(f"SELECT * FROM {tabla_nombre}", conn)
        
        # Si es la primera tabla, crear el archivo Excel, sino agregar una nueva hoja
        if os.path.exists(ruta_archivo):
            with pd.ExcelWriter(ruta_archivo, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                df.to_excel(writer, sheet_name=tabla_nombre, index=False)
        else:
            with pd.ExcelWriter(ruta_archivo, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name=tabla_nombre, index=False)
        
        conn.close()
        return True
    except Exception as e:
        print(f"Error exportando tabla {tabla_nombre}: {e}")
        return False

def enviar_email_con_reporte(email_destino, archivo_excel, tablas_seleccionadas):
    """Envía el reporte por email"""
    try:
        # Configuración del email (puedes ajustar estos valores)
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        email_remitente = "tu_email@gmail.com"  # Configura tu email
        password_remitente = "tu_app_password"   # Configura tu app password de Gmail
        
        # Crear mensaje
        msg = MIMEMultipart()
        msg['From'] = email_remitente
        msg['To'] = email_destino
        msg['Subject'] = f"Reporte del Gimnasio - {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        
        # Cuerpo del email
        tablas_texto = ", ".join(tablas_seleccionadas)
        cuerpo = f"""
        Estimado/a,
        
        Se adjunta el reporte solicitado del sistema de gestión del gimnasio.
        
        Tablas incluidas: {tablas_texto}
        Fecha de generación: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
        
        Saludos cordiales,
        Sistema de Gestión del Gimnasio
        """
        
        msg.attach(MIMEText(cuerpo, 'plain'))
        
        # Adjuntar archivo Excel
        with open(archivo_excel, "rb") as attachment:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment.read())
        
        encoders.encode_base64(part)
        part.add_header(
            'Content-Disposition',
            f'attachment; filename= reporte_gimnasio_{datetime.now().strftime("%Y%m%d_%H%M")}.xlsx'
        )
        msg.attach(part)
        
        # Enviar email
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(email_remitente, password_remitente)
        text = msg.as_string()
        server.sendmail(email_remitente, email_destino, text)
        server.quit()
        
        return True
    except Exception as e:
        print(f"Error enviando email: {e}")
        return False

def mostrar_selector_tablas(page, email_admin):
    """Muestra el diálogo para seleccionar tablas y enviar reporte"""
    config = cargar_configuracion()
    tablas = obtener_tablas_bd()
    
    if not tablas:
        # Mostrar error si no hay tablas
        dialog_error = ft.AlertDialog(
            title=ft.Text("Error", color="red", text_align="center"),
            content=ft.Text("No se pudieron obtener las tablas de la base de datos", 
                          color=config["color_letras"], text_align="center"),
            actions=[ft.TextButton("Cerrar", on_click=lambda e: cerrar_dialogo(dialog_error, page))],
            bgcolor=config["color_fondo"]
        )
        page.dialog = dialog_error
        dialog_error.open = True
        page.update()
        return
    
    # Estado de selección de tablas
    tablas_seleccionadas = {tabla: False for tabla in tablas}
    
    def cerrar_dialogo(dialog, page):
        dialog.open = False
        page.update()
    
    def toggle_tabla(tabla_nombre):
        def on_change(e):
            tablas_seleccionadas[tabla_nombre] = e.control.value
            # Actualizar el estado del botón enviar
            btn_enviar.disabled = not any(tablas_seleccionadas.values())
            btn_enviar.update()
        return on_change
    
    def enviar_reporte(e):
        # Obtener tablas seleccionadas
        tablas_a_exportar = [tabla for tabla, seleccionada in tablas_seleccionadas.items() if seleccionada]
        
        if not tablas_a_exportar:
            return
        
        # Crear archivo temporal
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            archivo_excel = tmp_file.name
        
        try:
            # Mostrar progreso
            dialog_selector.content = ft.Container(
                content=ft.Column([
                    ft.ProgressRing(),
                    ft.Text("Generando reporte...", color=config["color_letras"], text_align="center"),
                    ft.Text("Por favor espere...", color=config["color_letras"], text_align="center", size=12)
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=20,
                alignment=ft.alignment.center
            )
            page.update()
            
            # Exportar tablas seleccionadas
            for tabla in tablas_a_exportar:
                if not exportar_tabla_a_excel(tabla, archivo_excel):
                    raise Exception(f"Error exportando tabla {tabla}")
            
            # Enviar por email
            if enviar_email_con_reporte(email_admin, archivo_excel, tablas_a_exportar):
                # Éxito
                dialog_selector.content = ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.CHECK_CIRCLE, color="green", size=48),
                        ft.Text("¡Reporte enviado exitosamente!", color="green", text_align="center", weight="bold"),
                        ft.Text(f"Enviado a: {email_admin}", color=config["color_letras"], text_align="center", size=12),
                        ft.Text(f"Tablas: {', '.join(tablas_a_exportar)}", color=config["color_letras"], text_align="center", size=12)
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=20,
                    alignment=ft.alignment.center
                )
                dialog_selector.actions = [ft.TextButton("Cerrar", on_click=lambda e: cerrar_dialogo(dialog_selector, page))]
            else:
                raise Exception("Error enviando email")
                
        except Exception as ex:
            # Error
            dialog_selector.content = ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.ERROR, color="red", size=48),
                    ft.Text("Error enviando reporte", color="red", text_align="center", weight="bold"),
                    ft.Text(str(ex), color="red", text_align="center", size=12)
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=20,
                alignment=ft.alignment.center
            )
            dialog_selector.actions = [ft.TextButton("Cerrar", on_click=lambda e: cerrar_dialogo(dialog_selector, page))]
        
        finally:
            # Limpiar archivo temporal
            try:
                os.unlink(archivo_excel)
            except:
                pass
        
        page.update()
    
    # Crear checkboxes para cada tabla
    checkboxes = []
    for tabla in tablas:
        checkbox = ft.Checkbox(
            label=tabla.replace('_', ' ').title(),
            value=False,
            active_color=config["color_tematica"],
            on_change=toggle_tabla(tabla)
        )
        checkboxes.append(checkbox)
    
    # Botón para seleccionar/deseleccionar todas
    def toggle_todas(e):
        nuevo_estado = e.control.value
        for tabla in tablas_seleccionadas:
            tablas_seleccionadas[tabla] = nuevo_estado
        for checkbox in checkboxes:
            checkbox.value = nuevo_estado
            checkbox.update()
        btn_enviar.disabled = not nuevo_estado
        btn_enviar.update()
    
    checkbox_todas = ft.Checkbox(
        label="Seleccionar todas las tablas",
        value=False,
        active_color=config["color_tematica"],
        on_change=toggle_todas
    )
    
    # Botón enviar (inicialmente deshabilitado)
    btn_enviar = ft.ElevatedButton(
        "Enviar Reporte",
        icon=ft.Icons.SEND,
        on_click=enviar_reporte,
        disabled=True,
        style=ft.ButtonStyle(bgcolor=config["color_tematica"])
    )
    
    # Crear diálogo
    dialog_selector = ft.AlertDialog(
        title=ft.Text("Seleccionar Tablas para Reporte", color=config["color_tematica"], text_align="center", weight="bold"),
        content=ft.Container(
            content=ft.Column([
                ft.Text(f"Email destino: {email_admin}", color=config["color_letras"], size=12, text_align="center"),
                ft.Divider(color=config["color_tematica"]),
                checkbox_todas,
                ft.Divider(color=config["color_tematica"]),
                ft.Container(
                    content=ft.Column(checkboxes, scroll="auto"),
                    height=200,
                    width=300
                )
            ], spacing=10),
            padding=10
        ),
        actions=[
            ft.TextButton("Cancelar", on_click=lambda e: cerrar_dialogo(dialog_selector, page)),
            btn_enviar
        ],
        actions_alignment=ft.MainAxisAlignment.END,
        bgcolor=config["color_fondo"]
    )
    
    page.dialog = dialog_selector
    dialog_selector.open = True
    page.update()
